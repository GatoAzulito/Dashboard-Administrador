# Dashboard Administrador - Gimnasio

Aplicación web de demostración hecha con **Streamlit** para administrar una cadena de gimnasios: panel de sedes, socios, planes, congelamientos, alertas de permanencia, comunicaciones, auditoría y finanzas.

> Es una demo funcional con datos ficticios. La información se guarda en memoria y se reinicia al cerrar el servidor.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.13).
- Windows, macOS o Linux.
- Conexión a internet solo la primera vez, para instalar las dependencias.

## Inicio rápido en Windows

1. Descomprime la carpeta del proyecto.
2. Haz doble clic en **`iniciar.bat`**.
3. La primera vez crea el entorno virtual e instala las dependencias (puede tardar unos minutos).
4. Se abrirá el navegador en `http://localhost:8501`.

Si prefieres hacerlo manualmente:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run demo_login.py
```

Si PowerShell bloquea la activación:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## Inicio rápido en macOS o Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run demo_login.py
```

También puedes ejecutar `bash iniciar.sh`.

## Usuarios de demostración

| Usuario | Contraseña | Alcance |
|---|---|---|
| `admin` | `admin123` | Toda la cadena y todos los módulos |
| `gerente1` | `gerente123` | Zona Oriente |
| `gerente2` | `gerente123` | Zona Centro |
| `gerente3` | `gerente123` | Zona Sur |

Los gerentes solo ven las sedes de su zona. El módulo de **Planes de membresía** es exclusivo de `admin`.

## Módulos incluidos

- **Panel:** socios presentes, ocupación, membresías por vencer y pendientes.
- **Socios:** búsqueda por nombre/RUT, ficha editable, desactivación con historial y registro de nuevos socios.
- **Planes de membresía:** edición de precios, duración, alcance y estado.
- **Congelamientos:** aprobación o rechazo de solicitudes; al aprobar se extiende la membresía.
- **Alertas de permanencia:** socios con más de 2 horas en sede sin salida.
- **Comunicaciones y eventos:** creación y publicación de eventos, envíos por Email/WhatsApp/SMS e historial.
- **Auditoría:** registro de acciones por usuario, módulo y sede, con filtros y exportación CSV.
- **Finanzas:** últimos pagos, ventas mensuales y ventas por sede.

## Estructura del proyecto

```
Dashboard Administrador/
├── demo_login.py                  # Aplicación principal
├── requirements.txt               # Dependencias
├── iniciar.bat                    # Arranque para Windows
├── iniciar.sh                     # Arranque para macOS/Linux
├── README.md
├── .gitignore
└── Planilla de Requerimientos v2.xlsx
```

## Notas importantes

- **No copies la carpeta `.venv`** entre computadores: contiene rutas y binarios del equipo donde se creó. Cada PC debe generar la suya con `iniciar.bat` o los comandos manuales.
- Cada persona que ejecute la app tendrá su propia sesión y sus propios datos; no se comparten cambios entre equipos.
- La app abre en `http://localhost:8501`. Si el puerto está ocupado, usa:

```powershell
streamlit run demo_login.py --server.port 8502
```

- Para acceder desde otro equipo en la misma red:

```powershell
streamlit run demo_login.py --server.address 0.0.0.0
```

## Problemas frecuentes

**`streamlit` no se reconoce como comando**
Activa el entorno virtual antes de ejecutar (`Activate.ps1` en Windows o `source .venv/bin/activate` en macOS/Linux), o usa `iniciar.bat`.

**Error al crear el entorno virtual en Windows**
Si aparece un error copiando `venvlauncher.exe`, prueba:

```powershell
python -m venv --copies .venv
```

O instala Python desde <https://www.python.org/downloads/> marcando la opción "Add Python to PATH".

**La página no carga**
Revisa la terminal: Streamlit muestra la URL y el puerto reales. También puedes abrir `http://localhost:8501` manualmente.

## Aviso

Las contraseñas están escritas en el código y los datos son ficticios. Esta aplicación es una demostración educativa: no debe usarse con datos personales reales sin antes implementar autenticación segura, base de datos y respaldos.
