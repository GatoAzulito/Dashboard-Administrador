import random
from datetime import date, datetime, time, timedelta

import altair as alt
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Dashboard Administrador", layout="wide")

TIMEOUT_MINUTOS = 15
UMBRAL_ALERTA = 85  # % de aforo que dispara la alerta

SEDES = [
    "Santiago",
    "Providencia",
    "Ñuñoa",
    "Las Condes",
    "La Reina",
    "Macul",
    "San Miguel",
    "La Florida",
    "Peñalolén",
    "La Cisterna",
    "San Joaquín",
    "Recoleta",
    "Independencia",
    "Quinta Normal",
    "Estación Central",
    "Cerrillos",
    "Maipú",
    "Vitacura",
    "Lo Barnechea",
    "Puente Alto",
]

PRESENTES = [
    32, 28, 22, 37, 14, 19, 21, 26, 20, 17,
    13, 18, 12, 16, 24, 15, 30, 23, 11, 27,
]

AFOROS = [
    45, 40, 35, 50, 25, 30, 30, 40, 35, 30,
    25, 30, 25, 30, 35, 30, 45, 35, 25, 40,
]

INFO_SEDES = {
    "Santiago": {"direccion": "Av. Libertador Bernardo O'Higgins 1234", "horario": "L-V 06:00-23:00 · S-D 08:00-20:00"},
    "Providencia": {"direccion": "Av. Providencia 2120", "horario": "L-V 06:00-23:00 · S-D 08:00-20:00"},
    "Ñuñoa": {"direccion": "Av. Irarrázaval 3450", "horario": "L-V 06:30-22:30 · S-D 09:00-20:00"},
    "Las Condes": {"direccion": "Av. Apoquindo 4900", "horario": "L-V 06:00-23:30 · S-D 08:00-21:00"},
    "La Reina": {"direccion": "Av. Larraín 8800", "horario": "L-V 07:00-22:00 · S-D 09:00-19:00"},
    "Macul": {"direccion": "Av. Vicuña Mackenna 4800", "horario": "L-V 06:30-22:30 · S-D 09:00-19:00"},
    "San Miguel": {"direccion": "Gran Avenida 3200", "horario": "L-V 06:00-22:30 · S-D 08:30-19:00"},
    "La Florida": {"direccion": "Av. Vicuña Mackenna 7100", "horario": "L-V 06:00-23:00 · S-D 08:00-20:00"},
    "Peñalolén": {"direccion": "Av. Grecia 5600", "horario": "L-V 06:30-22:00 · S-D 09:00-19:00"},
    "La Cisterna": {"direccion": "Gran Avenida 8900", "horario": "L-V 06:30-22:00 · S-D 09:00-18:00"},
    "San Joaquín": {"direccion": "Av. Santa Rosa 3400", "horario": "L-V 07:00-22:00 · S-D 09:00-18:00"},
    "Recoleta": {"direccion": "Av. Recoleta 1500", "horario": "L-V 06:30-22:30 · S-D 08:30-19:00"},
    "Independencia": {"direccion": "Av. Independencia 2100", "horario": "L-V 07:00-22:00 · S-D 09:00-18:00"},
    "Quinta Normal": {"direccion": "Av. Mapocho 2500", "horario": "L-V 07:00-22:00 · S-D 09:00-19:00"},
    "Estación Central": {"direccion": "Av. Alameda 3800", "horario": "L-V 06:00-23:00 · S-D 08:00-20:00"},
    "Cerrillos": {"direccion": "Av. Pedro Aguirre Cerda 5200", "horario": "L-V 07:00-22:00 · S-D 09:00-19:00"},
    "Maipú": {"direccion": "Av. Pajaritos 1900", "horario": "L-V 06:00-23:00 · S-D 08:00-20:00"},
    "Vitacura": {"direccion": "Av. Vitacura 6200", "horario": "L-V 06:00-23:30 · S-D 08:00-21:00"},
    "Lo Barnechea": {"direccion": "Av. El Rodeo 12000", "horario": "L-V 07:00-22:00 · S-D 09:00-19:00"},
    "Puente Alto": {"direccion": "Av. Concha y Toro 1800", "horario": "L-V 06:00-22:30 · S-D 08:00-20:00"},
}

NOMBRES = [
    "Matías", "Javiera", "Sebastián", "Catalina", "Diego", "Fernanda",
    "Cristóbal", "Valentina", "Ignacio", "Camila", "Felipe", "Antonia",
    "Vicente", "Martina", "Joaquín", "Isidora", "Benjamín", "Sofía",
    "Tomás", "Emilia", "Agustín", "Florencia", "Nicolás", "Constanza",
    "Álvaro", "Josefa", "Rodrigo", "Daniela", "Andrés", "Francisca",
]

APELLIDOS = [
    "González", "Muñoz", "Rojas", "Díaz", "Pérez", "Soto", "Contreras",
    "Silva", "Martínez", "Sepúlveda", "Morales", "Rodríguez", "López",
    "Fuentes", "Hernández", "Torres", "Araya", "Flores", "Espinoza",
    "Valdés", "Castillo", "Tapia", "Reyes", "Gutiérrez", "Castro",
]

ZONAS = {
    "gerente1": ["Providencia", "Las Condes", "Vitacura", "Lo Barnechea", "La Reina", "Ñuñoa"],
    "gerente2": ["Santiago", "Recoleta", "Independencia", "Quinta Normal", "Estación Central", "Cerrillos"],
    "gerente3": ["Maipú", "Puente Alto", "La Florida", "Peñalolén", "Macul", "San Miguel", "La Cisterna", "San Joaquín"],
}

USUARIOS = {
    "admin": {
        "clave": "admin123",
        "nombre": "Administrador General",
        "rol": "Administrador",
        "sedes": SEDES,
    },
    "gerente1": {
        "clave": "gerente123",
        "nombre": "Gerente Zona Oriente",
        "rol": "Gerente",
        "sedes": ZONAS["gerente1"],
    },
    "gerente2": {
        "clave": "gerente123",
        "nombre": "Gerente Zona Centro",
        "rol": "Gerente",
        "sedes": ZONAS["gerente2"],
    },
    "gerente3": {
        "clave": "gerente123",
        "nombre": "Gerente Zona Sur",
        "rol": "Gerente",
        "sedes": ZONAS["gerente3"],
    },
}

MODULOS = [
    "Panel",
    "Socios",
    "Planes de membresía",
    "Congelamientos",
    "Alertas de permanencia",
    "Comunicaciones y eventos",
    "Auditoría",
    "Finanzas",
]

MESES_ES = [
    "Ene", "Feb", "Mar", "Abr", "May", "Jun",
    "Jul", "Ago", "Sep", "Oct", "Nov", "Dic",
]


# ---------------------------------------------------------------------------
# Utilidades y control de acceso
# ---------------------------------------------------------------------------

def es_admin() -> bool:
    return st.session_state.get("rol") == "Administrador"


def sedes_permitidas() -> list:
    if es_admin():
        return SEDES
    return [s for s in SEDES if s in st.session_state.get("sedes", [])]


def filtrar_por_sede(df: pd.DataFrame, sede_sel: str) -> pd.DataFrame:
    if sede_sel != "Todas las sedes":
        return df[df["Sede"] == sede_sel]
    return df[df["Sede"].isin(sedes_permitidas())]


def _dv_rut(numero: int) -> str:
    """Calcula el dígito verificador de un RUT chileno."""
    suma, factor = 0, 2
    while numero:
        suma += (numero % 10) * factor
        numero //= 10
        factor = 2 if factor == 7 else factor + 1
    resto = 11 - suma % 11
    return {11: "0", 10: "K"}.get(resto, str(resto))


def formato_clp(valor) -> str:
    return f"${valor:,.0f}".replace(",", ".")


def estado_membresia(vencimiento: date) -> str:
    hoy = date.today()
    if vencimiento < hoy - timedelta(days=7):
        return "Bloqueada por deuda"
    if vencimiento < hoy:
        return "En gracia"
    if vencimiento <= hoy + timedelta(days=7):
        return "Por vencer"
    return "Vigente"


def socios_con_estado(df: pd.DataFrame) -> pd.DataFrame:
    copia = df.copy()
    copia["Estado membresía"] = copia["Vencimiento"].apply(estado_membresia)
    return copia


def datos_sedes() -> pd.DataFrame:
    """Presentes reales por sede (según la base de socios) y aforo configurado."""
    conteo = (
        st.session_state.socios[st.session_state.socios["Presente"]]
        .groupby("Sede")
        .size()
    )
    filas = [
        {"Sede": sede, "Presentes": int(conteo.get(sede, 0)), "Aforo": aforo}
        for sede, aforo in zip(SEDES, AFOROS)
        if sede in sedes_permitidas()
    ]
    return pd.DataFrame(filas)


def registrar_auditoria(modulo: str, accion: str, detalle: str, sede: str = "—"):
    """Agrega una entrada inmutable al registro de auditoría."""
    st.session_state.auditoria.append(
        {
            "Fecha y hora": datetime.now(),
            "Usuario": st.session_state.get("usuario", "—"),
            "Rol": st.session_state.get("rol", "—"),
            "Módulo": modulo,
            "Acción": accion,
            "Detalle": detalle,
            "Sede": sede,
            "IP": "127.0.0.1",
        }
    )


# ---------------------------------------------------------------------------
# Datos de demostración
# ---------------------------------------------------------------------------

def generar_base_socios() -> pd.DataFrame:
    """Base única de socios: presentes + algunos no presentes por sede."""
    rnd = random.Random("socios-demo")
    usados_rut, usados_nombre = set(), set()
    hoy = date.today()
    planes = ["Mensual", "Mensual Full", "Semestral", "Semestral Full", "Anual", "Anual Full"]
    filas = []

    for sede, presentes in zip(SEDES, PRESENTES):
        for i in range(presentes + 8):  # presentes + socios no presentes
            nombre = f"{rnd.choice(NOMBRES)} {rnd.choice(APELLIDOS)} {rnd.choice(APELLIDOS)}"
            while nombre in usados_nombre:
                nombre = f"{rnd.choice(NOMBRES)} {rnd.choice(APELLIDOS)} {rnd.choice(APELLIDOS)}"
            usados_nombre.add(nombre)

            numero = rnd.randint(8_000_000, 25_000_000)
            while numero in usados_rut:
                numero = rnd.randint(8_000_000, 25_000_000)
            usados_rut.add(numero)

            filas.append(
                {
                    "Nombre": nombre,
                    "RUT": f"{numero:,}".replace(",", ".") + f"-{_dv_rut(numero)}",
                    "Email": f"{nombre.split()[0].lower()}.{str(numero)[-4:]}@correo.cl",
                    "Teléfono": f"+56 9 {rnd.randint(1000, 9999)} {rnd.randint(1000, 9999)}",
                    "Sede": sede,
                    "Plan": rnd.choice(planes),
                    "Vencimiento": hoy + timedelta(days=rnd.randint(-20, 330)),
                    "Estado": "Activo",
                    "Presente": i < presentes,
                    "Consentimiento": rnd.random() > 0.15,
                }
            )

    return pd.DataFrame(filas)


def generar_congelamientos(socios: pd.DataFrame) -> pd.DataFrame:
    rnd = random.Random("congelamientos")
    motivos = [
        "Viaje al extranjero",
        "Licencia médica",
        "Motivos laborales",
        "Estudios",
        "Embarazo",
    ]
    hoy = date.today()
    muestra = socios.sample(n=9, random_state=7).reset_index(drop=True)
    estados = ["Pendiente"] * 5 + ["Aprobado"] * 2 + ["Rechazado"] * 2
    filas = []

    for i, socio in muestra.iterrows():
        inicio = hoy + timedelta(days=rnd.randint(3, 20))
        fin = inicio + timedelta(days=rnd.randint(15, 60))
        filas.append(
            {
                "Socio": socio["Nombre"],
                "RUT": socio["RUT"],
                "Sede": socio["Sede"],
                "Fecha solicitud": hoy - timedelta(days=rnd.randint(1, 20)),
                "Inicio": inicio,
                "Fin": fin,
                "Justificación": rnd.choice(motivos),
                "Estado": estados[i],
            }
        )

    return pd.DataFrame(filas)


def generar_alertas(socios: pd.DataFrame) -> pd.DataFrame:
    rnd = random.Random("alertas")
    presentes = socios[socios["Presente"]].sample(n=12, random_state=11).reset_index(drop=True)
    ahora = datetime.now()
    filas = []

    for i, socio in presentes.iterrows():
        ingreso = ahora - timedelta(minutes=rnd.randint(125, 260))
        filas.append(
            {
                "Socio": socio["Nombre"],
                "RUT": socio["RUT"],
                "Sede": socio["Sede"],
                "Hora ingreso": ingreso,
                "Minutos en sede": int((ahora - ingreso).total_seconds() // 60),
                "Estado": "Pendiente" if i < 9 else "Atendida",
            }
        )

    return pd.DataFrame(filas)


def planes_iniciales() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {"Plan": "Mensual", "Duración (meses)": 1, "Precio (CLP)": 29990, "Alcance": "Una sede", "Activo": True},
            {"Plan": "Mensual Full", "Duración (meses)": 1, "Precio (CLP)": 39990, "Alcance": "Toda la cadena", "Activo": True},
            {"Plan": "Semestral", "Duración (meses)": 6, "Precio (CLP)": 159990, "Alcance": "Una sede", "Activo": True},
            {"Plan": "Semestral Full", "Duración (meses)": 6, "Precio (CLP)": 209990, "Alcance": "Toda la cadena", "Activo": True},
            {"Plan": "Anual", "Duración (meses)": 12, "Precio (CLP)": 279990, "Alcance": "Una sede", "Activo": True},
            {"Plan": "Anual Full", "Duración (meses)": 12, "Precio (CLP)": 359990, "Alcance": "Toda la cadena", "Activo": True},
        ]
    )


def eventos_iniciales() -> pd.DataFrame:
    hoy = date.today()
    return pd.DataFrame(
        [
            {"Evento": "Clase abierta de yoga", "Sede": "Providencia", "Fecha": hoy + timedelta(days=5), "Hora": time(19, 0), "Descripción": "Sesión para socios e invitados.", "Estado": "Programado"},
            {"Evento": "Torneo de crossfit", "Sede": "Las Condes", "Fecha": hoy + timedelta(days=12), "Hora": time(10, 0), "Descripción": "Competencia interna por equipos.", "Estado": "Programado"},
            {"Evento": "Charla de nutrición", "Sede": "Toda la cadena", "Fecha": hoy + timedelta(days=20), "Hora": time(18, 30), "Descripción": "Transmisión online para todos los socios.", "Estado": "Publicado"},
            {"Evento": "Aniversario sede Maipú", "Sede": "Maipú", "Fecha": hoy + timedelta(days=30), "Hora": time(12, 0), "Descripción": "Celebración con actividades abiertas.", "Estado": "Programado"},
        ]
    )


def comunicaciones_iniciales() -> pd.DataFrame:
    ahora = datetime.now()
    return pd.DataFrame(
        [
            {"Fecha": ahora - timedelta(days=3), "Asunto": "Vencimiento de membresía", "Canal": "Email", "Destinatarios": "Socios por vencer", "Estado": "Enviada", "Usuario": "admin"},
            {"Fecha": ahora - timedelta(days=2), "Asunto": "Nuevo horario de verano", "Canal": "WhatsApp", "Destinatarios": "Todas las sedes", "Estado": "Enviada", "Usuario": "gerente1"},
            {"Fecha": ahora - timedelta(days=1), "Asunto": "Recordatorio de pago", "Canal": "SMS", "Destinatarios": "Socios con deuda", "Estado": "Enviada", "Usuario": "gerente2"},
        ]
    )


def auditoria_inicial() -> list:
    ahora = datetime.now()
    return [
        {"Fecha y hora": ahora - timedelta(days=2, hours=3), "Usuario": "admin", "Rol": "Administrador", "Módulo": "Planes", "Acción": "Actualización", "Detalle": "Modificó el precio del plan Anual Full", "Sede": "—", "IP": "10.0.0.5"},
        {"Fecha y hora": ahora - timedelta(days=1, hours=5), "Usuario": "gerente1", "Rol": "Gerente", "Módulo": "Socios", "Acción": "Edición", "Detalle": "Actualizó el teléfono de un socio", "Sede": "Providencia", "IP": "10.0.1.21"},
        {"Fecha y hora": ahora - timedelta(days=1, hours=2), "Usuario": "gerente2", "Rol": "Gerente", "Módulo": "Congelamientos", "Acción": "Aprobación", "Detalle": "Aprobó un congelamiento por viaje", "Sede": "Santiago", "IP": "10.0.2.33"},
        {"Fecha y hora": ahora - timedelta(hours=6), "Usuario": "gerente3", "Rol": "Gerente", "Módulo": "Alertas", "Acción": "Atención", "Detalle": "Marcó como atendida una alerta de permanencia", "Sede": "Maipú", "IP": "10.0.3.14"},
        {"Fecha y hora": ahora - timedelta(hours=2), "Usuario": "admin", "Rol": "Administrador", "Módulo": "Comunicaciones", "Acción": "Envío", "Detalle": "Envió un aviso de evento especial por email", "Sede": "—", "IP": "10.0.0.5"},
    ]


def generar_pagos(socios: pd.DataFrame, cantidad: int = 30) -> pd.DataFrame:
    """Últimos pagos, tomados de la base de socios visible."""
    if socios.empty:
        return pd.DataFrame(columns=["Socio", "RUT", "Sede", "Fecha de pago"])

    rnd = random.Random("pagos-demo")
    muestra = socios.sample(n=min(cantidad, len(socios)), random_state=42)
    hoy = date.today()
    filas = []

    for _, socio in muestra.iterrows():
        filas.append(
            {
                "Socio": socio["Nombre"],
                "RUT": socio["RUT"],
                "Sede": socio["Sede"],
                "Fecha de pago": hoy - timedelta(days=rnd.randint(0, 30)),
            }
        )

    filas.sort(key=lambda fila: fila["Fecha de pago"], reverse=True)
    for fila in filas:
        fila["Fecha de pago"] = fila["Fecha de pago"].strftime("%d-%m-%Y")
    return pd.DataFrame(filas)


def serie_ventas_mensual(factor: float = 1.0) -> pd.DataFrame:
    base = [
        42_500_000, 44_800_000, 47_200_000, 45_600_000,
        49_100_000, 51_300_000, 53_800_000, 50_900_000,
        55_400_000, 57_200_000, 59_600_000, 61_500_000,
    ]
    valores = [int(valor * factor) for valor in base]
    hoy = date.today()
    meses = []

    for i in range(11, -1, -1):
        indice = hoy.year * 12 + (hoy.month - 1) - i
        year, mes = divmod(indice, 12)
        meses.append(f"{MESES_ES[mes]} {year}")

    return pd.DataFrame({"Mes": meses, "Ventas": valores})


def ventas_por_sede(total_12_meses: int, sedes: list) -> pd.DataFrame:
    rnd = random.Random("ventas-sede")
    pesos_todos = [aforo * rnd.uniform(0.85, 1.2) for aforo in AFOROS]
    pares = [(sede, peso) for sede, peso in zip(SEDES, pesos_todos) if sede in sedes]
    factor = total_12_meses / sum(peso for _, peso in pares)

    return pd.DataFrame(
        [
            {"Sede": sede, "Ventas": int(round(peso * factor, -3))}
            for sede, peso in pares
        ]
    )


# ---------------------------------------------------------------------------
# Estado de la sesión
# ---------------------------------------------------------------------------

def init_state():
    valores_iniciales = {
        "logueado": False,
        "usuario": "",
        "nombre": "",
        "rol": "",
        "sedes": [],
        "ultima_actividad": None,
        "vista": "Panel",
    }
    for clave, valor in valores_iniciales.items():
        st.session_state.setdefault(clave, valor)

    if "socios" not in st.session_state:
        socios = generar_base_socios()
        st.session_state.socios = socios
        st.session_state.congelamientos = generar_congelamientos(socios)
        st.session_state.alertas = generar_alertas(socios)
        st.session_state.planes = planes_iniciales()
        st.session_state.eventos = eventos_iniciales()
        st.session_state.comunicaciones = comunicaciones_iniciales()
        st.session_state.auditoria = auditoria_inicial()


def cerrar_sesion():
    st.session_state.logueado = False
    st.session_state.usuario = ""
    st.session_state.nombre = ""
    st.session_state.rol = ""
    st.session_state.sedes = []
    st.session_state.ultima_actividad = None
    st.session_state.vista = "Panel"
    st.session_state.pop("sede_sel", None)
    st.rerun()


# ---------------------------------------------------------------------------
# Autenticación y barra lateral
# ---------------------------------------------------------------------------

def pantalla_login():
    st.title("Acceso administrador")
    st.caption(
        "Usuarios demo: admin / admin123 · gerente1, gerente2 y gerente3 / gerente123"
    )

    with st.form("form_login"):
        usuario = st.text_input("Usuario")
        clave = st.text_input("Contraseña", type="password")
        enviar = st.form_submit_button("Ingresar", width="stretch")

    if enviar:
        datos_usuario = USUARIOS.get(usuario)
        if datos_usuario and datos_usuario["clave"] == clave:
            st.session_state.logueado = True
            st.session_state.usuario = usuario
            st.session_state.nombre = datos_usuario["nombre"]
            st.session_state.rol = datos_usuario["rol"]
            st.session_state.sedes = datos_usuario["sedes"]
            st.session_state.ultima_actividad = datetime.now()
            st.session_state.vista = "Panel"
            st.session_state.pop("sede_sel", None)
            registrar_auditoria("Acceso", "Inicio de sesión", f"Ingreso de {usuario}")
            st.rerun()
        else:
            st.error("Usuario o contraseña incorrectos")


def barra_lateral() -> str:
    with st.sidebar:
        st.write(f"**{st.session_state.nombre}**")
        st.caption(f"{st.session_state.rol} · {st.session_state.usuario}")

        if st.button("Cerrar sesión", width="stretch"):
            registrar_auditoria("Acceso", "Cierre de sesión", "El usuario cerró sesión")
            cerrar_sesion()

        st.divider()
        with st.expander("Sedes", expanded=True):
            sede_sel = st.selectbox(
                "Elige una sede",
                ["Todas las sedes"] + sedes_permitidas(),
                key="sede_sel",
            )

        st.divider()
        modulos = [m for m in MODULOS if es_admin() or m != "Planes de membresía"]
        st.radio("Módulos", modulos, key="vista")
        st.caption("Datos de demostración. Los cambios se guardan en la sesión.")

    return sede_sel


# ---------------------------------------------------------------------------
# Vistas
# ---------------------------------------------------------------------------

def pantalla_panel():
    datos = datos_sedes()
    socios = socios_con_estado(filtrar_por_sede(st.session_state.socios, "Todas las sedes"))
    congel = filtrar_por_sede(st.session_state.congelamientos, "Todas las sedes")
    alertas = filtrar_por_sede(st.session_state.alertas, "Todas las sedes")

    st.title("Panel de control")

    total_presentes = int(datos["Presentes"].sum())
    ocupacion = datos["Presentes"].sum() / datos["Aforo"].sum() * 100

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Socios presentes", f"{total_presentes}")
    c2.metric("Ocupación promedio", f"{ocupacion:.1f} %")
    c3.metric("Membresías por vencer", int((socios["Estado membresía"] == "Por vencer").sum()))
    c4.metric("Congelamientos pendientes", int((congel["Estado"] == "Pendiente").sum()))

    pendientes_alerta = int((alertas["Estado"] == "Pendiente").sum())
    if pendientes_alerta:
        st.warning(f"Hay {pendientes_alerta} alertas de permanencia sin atender.")

    tab1, tab2 = st.tabs(["Sedes", "Reportes"])

    with tab1:
        st.dataframe(datos, width="stretch", hide_index=True)

    with tab2:
        st.bar_chart(datos.set_index("Sede")["Presentes"])


def pantalla_sede(sede: str):
    fila = datos_sedes()
    fila = fila[fila["Sede"] == sede].iloc[0]
    aforo = int(fila["Aforo"])

    socios_sede = st.session_state.socios[st.session_state.socios["Sede"] == sede]
    presentes = socios_sede[socios_sede["Presente"]].copy()
    presentes["Estado membresía"] = presentes["Vencimiento"].apply(estado_membresia)
    cantidad = len(presentes)
    ocupacion = cantidad / aforo * 100
    info = INFO_SEDES[sede]

    st.title(f"Gimnasio {sede}")

    st.subheader("Información de la sede")
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns(4)
        c1.markdown(f"**Dirección**  \n{info['direccion']}")
        c2.markdown(f"**Horario**  \n{info['horario']}")
        c3.markdown(f"**Aforo máximo**  \n{aforo} personas")
        c4.markdown("**Estado**  \nActiva")

    st.subheader("Ocupación actual")
    c1, c2, c3 = st.columns(3)
    c1.metric("Aforo utilizado", f"{ocupacion:.1f} %")
    c2.metric("Socios presentes", f"{cantidad}")
    c3.metric("Cupos disponibles", f"{aforo - cantidad}")
    st.progress(
        min(ocupacion / 100, 1.0),
        text=f"{cantidad} de {aforo} cupos ocupados",
    )
    if ocupacion >= UMBRAL_ALERTA:
        st.warning(f"La sede superó el umbral de alerta del {UMBRAL_ALERTA} % de aforo.")

    st.subheader("Socios presentes")
    st.caption(f"{cantidad} socios registrados dentro de la sede.")
    st.dataframe(
        presentes[["Nombre", "RUT", "Plan", "Vencimiento", "Estado membresía"]],
        width="stretch",
        hide_index=True,
    )


def pantalla_planes():
    st.title("Planes de membresía")
    st.caption(
        "Edita los valores en la tabla. Puedes agregar o eliminar filas y luego guardar."
    )

    editado = st.data_editor(
        st.session_state.planes,
        num_rows="dynamic",
        width="stretch",
        column_config={
            "Plan": st.column_config.TextColumn("Plan", required=True),
            "Duración (meses)": st.column_config.NumberColumn(
                "Duración (meses)", min_value=1, max_value=24, step=1
            ),
            "Precio (CLP)": st.column_config.NumberColumn(
                "Precio (CLP)", min_value=0, step=1000, format="$ %d"
            ),
            "Alcance": st.column_config.SelectboxColumn(
                "Alcance", options=["Una sede", "Toda la cadena"], required=True
            ),
            "Activo": st.column_config.CheckboxColumn("Activo"),
        },
        key="editor_planes",
    )

    if st.button("Guardar cambios", type="primary"):
        editado = editado.dropna(subset=["Plan"])
        editado = editado[editado["Plan"].astype(str).str.strip() != ""]
        st.session_state.planes = editado
        registrar_auditoria(
            "Planes", "Actualización", f"Guardó {len(editado)} planes de membresía"
        )
        st.success("Planes guardados correctamente.")


def pantalla_socios(sede_sel: str):
    st.title("Gestión de socios")

    base = socios_con_estado(filtrar_por_sede(st.session_state.socios, sede_sel))

    c1, c2, c3 = st.columns([2, 1, 1])
    busqueda = c1.text_input("Buscar por nombre o RUT")
    filtro_cuenta = c2.selectbox("Cuenta", ["Todas", "Activo", "Inactivo"])
    filtro_mem = c3.selectbox(
        "Membresía",
        ["Todas", "Vigente", "Por vencer", "En gracia", "Bloqueada por deuda"],
    )

    filtrado = base
    if busqueda.strip():
        q = busqueda.strip().lower()
        q_rut = q.replace(".", "").replace("-", "").replace(" ", "")
        filtrado = filtrado[
            filtrado["Nombre"].str.lower().str.contains(q, na=False)
            | filtrado["RUT"]
            .str.lower()
            .str.replace(".", "", regex=False)
            .str.replace("-", "", regex=False)
            .str.contains(q_rut, na=False)
        ]
    if filtro_cuenta != "Todas":
        filtrado = filtrado[filtrado["Estado"] == filtro_cuenta]
    if filtro_mem != "Todas":
        filtrado = filtrado[filtrado["Estado membresía"] == filtro_mem]

    st.caption(f"{len(filtrado)} socios encontrados")
    st.dataframe(
        filtrado[
            ["Nombre", "RUT", "Sede", "Plan", "Vencimiento", "Estado membresía", "Estado", "Presente"]
        ],
        width="stretch",
        hide_index=True,
    )

    st.divider()
    st.subheader("Ficha del socio")

    if filtrado.empty:
        st.info("No hay socios que coincidan con el filtro.")
        return

    opciones = (filtrado["RUT"] + " · " + filtrado["Nombre"]).tolist()
    seleccion = st.selectbox("Selecciona un socio", opciones)
    rut = seleccion.split(" · ")[0]
    idx = st.session_state.socios.index[st.session_state.socios["RUT"] == rut][0]
    socio = st.session_state.socios.loc[idx]

    planes = st.session_state.planes["Plan"].tolist()
    if socio["Plan"] not in planes:
        planes.append(socio["Plan"])
    sedes_opciones = sedes_permitidas()

    with st.form("form_socio"):
        c1, c2 = st.columns(2)
        nombre = c1.text_input("Nombre", socio["Nombre"])
        email = c2.text_input("Email", socio["Email"])
        telefono = c1.text_input("Teléfono", socio["Teléfono"])
        sede = c2.selectbox(
            "Sede",
            sedes_opciones,
            index=sedes_opciones.index(socio["Sede"]) if socio["Sede"] in sedes_opciones else 0,
        )
        plan = c1.selectbox("Plan", planes, index=planes.index(socio["Plan"]))
        consentimiento = c2.checkbox(
            "Consentimiento para notificaciones", bool(socio["Consentimiento"])
        )
        guardar = st.form_submit_button("Guardar cambios")

    if guardar:
        st.session_state.socios.at[idx, "Nombre"] = nombre
        st.session_state.socios.at[idx, "Email"] = email
        st.session_state.socios.at[idx, "Teléfono"] = telefono
        st.session_state.socios.at[idx, "Sede"] = sede
        st.session_state.socios.at[idx, "Plan"] = plan
        st.session_state.socios.at[idx, "Consentimiento"] = consentimiento
        registrar_auditoria(
            "Socios", "Edición", f"Actualizó la ficha de {nombre} ({rut})", sede
        )
        st.success("Datos actualizados.")
        st.rerun()

    c1, c2 = st.columns(2)
    if socio["Estado"] == "Activo":
        if c1.button("Desactivar socio", type="primary"):
            st.session_state.socios.at[idx, "Estado"] = "Inactivo"
            st.session_state.socios.at[idx, "Presente"] = False
            registrar_auditoria(
                "Socios", "Desactivación", f"Desactivó a {socio['Nombre']} ({rut})", sede
            )
            st.success("Socio desactivado. Su historial se conserva.")
            st.rerun()
    else:
        if c1.button("Reactivar socio"):
            st.session_state.socios.at[idx, "Estado"] = "Activo"
            registrar_auditoria(
                "Socios", "Reactivación", f"Reactivó a {socio['Nombre']} ({rut})", sede
            )
            st.success("Socio reactivado.")
            st.rerun()

    with st.expander("Registrar nuevo socio"):
        with st.form("form_nuevo_socio", clear_on_submit=True):
            c1, c2 = st.columns(2)
            n_nombre = c1.text_input("Nombre completo")
            n_rut = c2.text_input("RUT", placeholder="12.345.678-9")
            n_email = c1.text_input("Email")
            n_telefono = c2.text_input("Teléfono")
            n_sede = c1.selectbox("Sede", sedes_opciones)
            n_plan = c2.selectbox("Plan", st.session_state.planes["Plan"].tolist())
            n_consentimiento = c1.checkbox("Consentimiento para notificaciones", value=True)
            crear = st.form_submit_button("Crear socio")

        if crear:
            if not n_nombre.strip() or not n_rut.strip():
                st.error("Nombre y RUT son obligatorios.")
            elif n_rut.strip() in st.session_state.socios["RUT"].values:
                st.error("Ya existe un socio con ese RUT.")
            else:
                nuevo = pd.DataFrame(
                    [
                        {
                            "Nombre": n_nombre.strip(),
                            "RUT": n_rut.strip(),
                            "Email": n_email.strip(),
                            "Teléfono": n_telefono.strip(),
                            "Sede": n_sede,
                            "Plan": n_plan,
                            "Vencimiento": date.today() + timedelta(days=30),
                            "Estado": "Activo",
                            "Presente": False,
                            "Consentimiento": n_consentimiento,
                        }
                    ]
                )
                st.session_state.socios = pd.concat(
                    [st.session_state.socios, nuevo], ignore_index=True
                )
                registrar_auditoria(
                    "Socios",
                    "Creación",
                    f"Registró a {n_nombre.strip()} ({n_rut.strip()})",
                    n_sede,
                )
                st.success("Socio registrado.")
                st.rerun()


def pantalla_congelamientos(sede_sel: str):
    st.title("Congelamientos")

    df = filtrar_por_sede(st.session_state.congelamientos, sede_sel)
    pendientes = df[df["Estado"] == "Pendiente"]

    c1, c2 = st.columns(2)
    c1.metric("Solicitudes pendientes", len(pendientes))
    c2.metric("Total registradas", len(df))

    st.subheader("Solicitudes")
    st.dataframe(df, width="stretch", hide_index=True)

    if pendientes.empty:
        st.info("No hay solicitudes pendientes.")
        return

    st.subheader("Resolver solicitud")
    opciones = (pendientes["RUT"] + " · " + pendientes["Socio"]).tolist()
    elegido = st.selectbox("Solicitud pendiente", opciones)
    rut = elegido.split(" · ")[0]
    idx = st.session_state.congelamientos.index[
        st.session_state.congelamientos["RUT"] == rut
    ][0]
    solicitud = st.session_state.congelamientos.loc[idx]

    c1, c2 = st.columns(2)
    if c1.button("Aprobar congelamiento", type="primary"):
        st.session_state.congelamientos.at[idx, "Estado"] = "Aprobado"
        dias = (solicitud["Fin"] - solicitud["Inicio"]).days
        mascara = st.session_state.socios["RUT"] == rut
        if mascara.any():
            idx_socio = st.session_state.socios.index[mascara][0]
            st.session_state.socios.at[idx_socio, "Vencimiento"] += timedelta(days=dias)
        registrar_auditoria(
            "Congelamientos",
            "Aprobación",
            f"Aprobó el congelamiento de {solicitud['Socio']} ({rut}) por {dias} días",
            solicitud["Sede"],
        )
        st.success("Congelamiento aprobado y membresía extendida.")
        st.rerun()

    if c2.button("Rechazar solicitud"):
        st.session_state.congelamientos.at[idx, "Estado"] = "Rechazado"
        registrar_auditoria(
            "Congelamientos",
            "Rechazo",
            f"Rechazó el congelamiento de {solicitud['Socio']} ({rut})",
            solicitud["Sede"],
        )
        st.success("Solicitud rechazada.")
        st.rerun()


def pantalla_alertas(sede_sel: str):
    st.title("Alertas de permanencia")
    st.caption(
        "Socios que superaron las 2 horas dentro de la sede sin registrar salida."
    )

    df = filtrar_por_sede(st.session_state.alertas, sede_sel).copy()
    pendientes = df[df["Estado"] == "Pendiente"]

    c1, c2 = st.columns(2)
    c1.metric("Alertas pendientes", len(pendientes))
    c2.metric("Alertas totales", len(df))

    vista = df.copy()
    vista["Minutos en sede"] = vista["Hora ingreso"].apply(
        lambda hora: int((datetime.now() - hora).total_seconds() // 60)
    )
    vista["Hora ingreso"] = vista["Hora ingreso"].dt.strftime("%d-%m-%Y %H:%M")

    st.subheader("Registro de alertas")
    st.dataframe(vista, width="stretch", hide_index=True)

    if pendientes.empty:
        st.info("No hay alertas pendientes.")
        return

    st.subheader("Atender alerta")
    opciones = (pendientes["RUT"] + " · " + pendientes["Socio"]).tolist()
    elegido = st.selectbox("Alerta pendiente", opciones)
    rut = elegido.split(" · ")[0]
    idx = st.session_state.alertas.index[st.session_state.alertas["RUT"] == rut][0]
    alerta = st.session_state.alertas.loc[idx]

    if st.button("Marcar como atendida", type="primary"):
        st.session_state.alertas.at[idx, "Estado"] = "Atendida"
        registrar_auditoria(
            "Alertas",
            "Atención",
            f"Atendió la alerta de permanencia de {alerta['Socio']} ({rut})",
            alerta["Sede"],
        )
        st.success("Alerta marcada como atendida.")
        st.rerun()


def pantalla_comunicaciones(sede_sel: str):
    st.title("Comunicaciones y eventos")

    tab_eventos, tab_comunicaciones = st.tabs(["Eventos", "Comunicaciones"])

    with tab_eventos:
        eventos = st.session_state.eventos.copy()
        if sede_sel != "Todas las sedes":
            eventos = eventos[
                (eventos["Sede"] == sede_sel) | (eventos["Sede"] == "Toda la cadena")
            ]
        else:
            eventos = eventos[
                eventos["Sede"].isin(sedes_permitidas() + ["Toda la cadena"])
            ]

        st.dataframe(eventos, width="stretch", hide_index=True)

        with st.expander("Crear evento"):
            with st.form("form_evento", clear_on_submit=True):
                nombre_evento = st.text_input("Nombre del evento")
                c1, c2 = st.columns(2)
                sede_evento = c1.selectbox(
                    "Sede", ["Toda la cadena"] + sedes_permitidas()
                )
                fecha_evento = c2.date_input(
                    "Fecha", value=date.today() + timedelta(days=7)
                )
                c3, c4 = st.columns(2)
                hora_evento = c3.time_input("Hora", value=time(19, 0))
                descripcion = c4.text_input("Descripción")
                crear = st.form_submit_button("Crear evento")

            if crear:
                if not nombre_evento.strip():
                    st.error("El nombre del evento es obligatorio.")
                else:
                    nuevo = pd.DataFrame(
                        [
                            {
                                "Evento": nombre_evento.strip(),
                                "Sede": sede_evento,
                                "Fecha": fecha_evento,
                                "Hora": hora_evento,
                                "Descripción": descripcion.strip(),
                                "Estado": "Programado",
                            }
                        ]
                    )
                    st.session_state.eventos = pd.concat(
                        [st.session_state.eventos, nuevo], ignore_index=True
                    )
                    registrar_auditoria(
                        "Comunicaciones",
                        "Creación de evento",
                        f"Creó el evento {nombre_evento.strip()}",
                        sede_evento,
                    )
                    st.success("Evento creado.")
                    st.rerun()

        programados = eventos[eventos["Estado"] == "Programado"]
        if not programados.empty:
            st.subheader("Publicar evento")
            etiquetas = [
                f"{idx} · {fila['Evento']} ({fila['Sede']})"
                for idx, fila in programados.iterrows()
            ]
            elegido = st.selectbox("Evento programado", etiquetas)
            idx_evento = int(elegido.split(" · ")[0])
            if st.button("Publicar evento"):
                st.session_state.eventos.at[idx_evento, "Estado"] = "Publicado"
                fila = st.session_state.eventos.loc[idx_evento]
                registrar_auditoria(
                    "Comunicaciones",
                    "Publicación de evento",
                    f"Publicó el evento {fila['Evento']}",
                    fila["Sede"],
                )
                st.success("Evento publicado y notificado a los socios.")
                st.rerun()

    with tab_comunicaciones:
        with st.form("form_comunicacion", clear_on_submit=True):
            asunto = st.text_input("Asunto")
            mensaje = st.text_area("Mensaje")
            c1, c2 = st.columns(2)
            canal = c1.selectbox("Canal", ["Email", "WhatsApp", "SMS"])
            destino = c2.selectbox(
                "Destinatarios",
                [
                    "Todos los socios",
                    "Socios por vencer",
                    "Socios con deuda",
                    "Socios de una sede",
                    "Socios de un plan",
                ],
            )
            c3, c4 = st.columns(2)
            sede_destino = c3.selectbox(
                "Sede (si aplica)", ["Toda la cadena"] + sedes_permitidas()
            )
            plan_destino = c4.selectbox(
                "Plan (si aplica)", ["Todos los planes"] + st.session_state.planes["Plan"].tolist()
            )
            enviar = st.form_submit_button("Enviar comunicación")

        if enviar:
            if not asunto.strip() or not mensaje.strip():
                st.error("Asunto y mensaje son obligatorios.")
            else:
                nuevo = pd.DataFrame(
                    [
                        {
                            "Fecha": datetime.now(),
                            "Asunto": asunto.strip(),
                            "Canal": canal,
                            "Destinatarios": destino,
                            "Estado": "Enviada",
                            "Usuario": st.session_state.usuario,
                        }
                    ]
                )
                st.session_state.comunicaciones = pd.concat(
                    [st.session_state.comunicaciones, nuevo], ignore_index=True
                )
                registrar_auditoria(
                    "Comunicaciones",
                    "Envío",
                    f"Envió '{asunto.strip()}' por {canal} a {destino}",
                    sede_destino,
                )
                st.success("Comunicación enviada (simulación).")
                st.rerun()

        st.subheader("Historial de comunicaciones")
        st.dataframe(
            st.session_state.comunicaciones.sort_values("Fecha", ascending=False),
            width="stretch",
            hide_index=True,
        )


def pantalla_auditoria():
    st.title("Auditoría")
    st.caption(
        "Registro inmutable de acciones: solo se agregan entradas, no se editan ni eliminan."
    )

    registros = pd.DataFrame(st.session_state.auditoria)
    if registros.empty:
        st.info("Sin registros de auditoría.")
        return

    if not es_admin():
        registros = registros[
            registros["Sede"].isin(sedes_permitidas()) | (registros["Sede"] == "—")
        ]

    registros = registros.sort_values("Fecha y hora", ascending=False)

    c1, c2 = st.columns(2)
    usuarios = c1.multiselect(
        "Usuario", sorted(registros["Usuario"].unique()), default=[]
    )
    modulos = c2.multiselect(
        "Módulo", sorted(registros["Módulo"].unique()), default=[]
    )

    if usuarios:
        registros = registros[registros["Usuario"].isin(usuarios)]
    if modulos:
        registros = registros[registros["Módulo"].isin(modulos)]

    vista = registros.copy()
    vista["Fecha y hora"] = vista["Fecha y hora"].dt.strftime("%d-%m-%Y %H:%M:%S")

    st.dataframe(vista, width="stretch", hide_index=True)
    st.download_button(
        "Descargar CSV",
        vista.to_csv(index=False).encode("utf-8-sig"),
        "auditoria.csv",
        "text/csv",
    )


def pantalla_finanzas(sede_sel: str):
    permitidas = sedes_permitidas()
    socios_filtrados = filtrar_por_sede(st.session_state.socios, sede_sel)
    pagos = generar_pagos(socios_filtrados)

    proporcion = sum(
        aforo for sede, aforo in zip(SEDES, AFOROS) if sede in permitidas
    ) / sum(AFOROS)
    ventas_mes = serie_ventas_mensual(proporcion)
    ventas_sede = ventas_por_sede(int(ventas_mes["Ventas"].sum()), permitidas)

    if sede_sel != "Todas las sedes":
        ventas_sede = ventas_sede[ventas_sede["Sede"] == sede_sel]
        ventas_mes = serie_ventas_mensual(
            next(a for s, a in zip(SEDES, AFOROS) if s == sede_sel) / sum(AFOROS)
        )

    st.title("Finanzas")

    c1, c2, c3 = st.columns(3)
    c1.metric("Ventas del mes", formato_clp(ventas_mes["Ventas"].iloc[-1]))
    c2.metric("Ventas últimos 12 meses", formato_clp(ventas_mes["Ventas"].sum()))
    c3.metric("Pagos registrados", f"{len(pagos)}")

    st.subheader("Últimos pagos")
    st.dataframe(pagos, width="stretch", hide_index=True)

    st.subheader("Ventas mensuales")
    st.bar_chart(ventas_mes.set_index("Mes")["Ventas"])

    st.subheader("Ventas totales por sede (últimos 12 meses)")
    grafico = (
        alt.Chart(ventas_sede)
        .mark_arc()
        .encode(
            theta=alt.Theta("Ventas:Q"),
            color=alt.Color(
                "Sede:N",
                scale=alt.Scale(scheme="tableau20"),
                legend=alt.Legend(title="Sede", columns=2),
            ),
            tooltip=[
                alt.Tooltip("Sede:N"),
                alt.Tooltip("Ventas:Q", format=",.0f", title="Ventas (CLP)"),
            ],
        )
    )
    st.altair_chart(grafico, width="stretch")


# ---------------------------------------------------------------------------
# Enrutado principal
# ---------------------------------------------------------------------------

def pantalla_dashboard():
    ahora = datetime.now()
    if ahora - st.session_state.ultima_actividad > timedelta(minutes=TIMEOUT_MINUTOS):
        st.warning("Sesión expirada por inactividad.")
        registrar_auditoria("Acceso", "Cierre de sesión", "Sesión expirada por inactividad")
        cerrar_sesion()
    st.session_state.ultima_actividad = ahora

    sede_sel = barra_lateral()
    vista = st.session_state.vista

    if vista == "Panel":
        if sede_sel != "Todas las sedes":
            pantalla_sede(sede_sel)
        else:
            pantalla_panel()
    elif vista == "Socios":
        pantalla_socios(sede_sel)
    elif vista == "Planes de membresía":
        if es_admin():
            pantalla_planes()
        else:
            st.warning("Solo el administrador puede gestionar los planes de membresía.")
    elif vista == "Congelamientos":
        pantalla_congelamientos(sede_sel)
    elif vista == "Alertas de permanencia":
        pantalla_alertas(sede_sel)
    elif vista == "Comunicaciones y eventos":
        pantalla_comunicaciones(sede_sel)
    elif vista == "Auditoría":
        pantalla_auditoria()
    elif vista == "Finanzas":
        pantalla_finanzas(sede_sel)


init_state()

if not st.session_state.logueado:
    pantalla_login()
else:
    pantalla_dashboard()
