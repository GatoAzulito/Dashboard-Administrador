@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   Dashboard Administrador - Gimnasio
echo ==========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo No se encontro Python.
    echo Instala Python 3.10 o superior desde https://www.python.org/downloads/
    echo Marca la opcion "Add Python to PATH" durante la instalacion.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creando entorno virtual...
    python -m venv .venv
    if errorlevel 1 (
        echo Reintentando con --copies...
        python -m venv --copies .venv
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo No se pudo crear el entorno virtual.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -c "import streamlit" >nul 2>nul
if errorlevel 1 (
    echo Instalando dependencias. Esto puede tardar unos minutos...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo No se pudieron instalar las dependencias.
        pause
        exit /b 1
    )
)

echo.
echo Iniciando la aplicacion...
echo Cuando termine, presiona Ctrl+C en esta ventana.
echo.
".venv\Scripts\streamlit.exe" run demo_login.py

pause
