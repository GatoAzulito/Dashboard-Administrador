#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "=========================================="
echo "  Dashboard Administrador - Gimnasio"
echo "=========================================="

if ! command -v python3 >/dev/null 2>&1; then
    echo "No se encontro python3. Instala Python 3.10 o superior."
    exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
    echo "Creando entorno virtual..."
    python3 -m venv .venv
fi

if ! .venv/bin/python -c "import streamlit" >/dev/null 2>&1; then
    echo "Instalando dependencias. Esto puede tardar unos minutos..."
    .venv/bin/python -m pip install --upgrade pip
    .venv/bin/python -m pip install -r requirements.txt
fi

echo
echo "Iniciando la aplicacion..."
echo "Cuando termine, presiona Ctrl+C en esta terminal."
echo
.venv/bin/streamlit run demo_login.py
